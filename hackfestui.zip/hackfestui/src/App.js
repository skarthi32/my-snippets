import React from "react";
import ReactDOM from "react-dom";
import "./App.css";
import axios from "axios";
import MaterialTable from "material-table";
import { InputLabel, Input, TextField } from "@material-ui/core";

class App extends React.Component {
  constructor(props) {
    super(props);
    this.handleChangeView = this.handleChangeView.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.biddingAmount = this.biddingAmount.bind(this);
    this.state = {
      persons: [],
      bidding: "",
      disabled: true,
      role: "User"
    };
  }

  biddingAmount(e) {}
  handleSubmit(e) {
    console.log(e.target[0]);
    e.preventDefault();
    let bidDetails = {
	  bondId : '0xf3c3196c3bbe03fdf1925f9690c84871dba9aa74',
      investorId : e.target[3].value,
      totalBiddingAmount: e.target[4].value,
      bidingCouponRate: e.target[5].value
    };
    //Below request will place a bid
    // Change the below URL to BID url
    // Change the bidDetails params as per the contract
    if (e.target[4].value > 16000) {
      alert("Bid amount cant be greatr than Bond Amount");
    } else {
      axios
        .post(`http://localhost:8080/bidding/deploy`, { bondId : '0xf3c3196c3bbe03fdf1925f9690c84871dba9aa74',
      investorId : e.target[3].value,
      totalBiddingAmount: e.target[4].value,
      bidingCouponRate: e.target[5].value })
        .then(res => {
          console.log(res);
          console.log(res.data);
        });
    }
  }
  handleChangeView(e) {
    console.log(e.role);
    let role = e.target.value;
    this.setState({ role: role });
    if (role === "Bid") {
      console.log("Bid selected");
      setTimeout(() => {
        console.log("enabled");
        this.setState({ disabled: false });
      }, 2000);
      setTimeout(() => {
        console.log("disabled back");
        this.setState({ disabled: true });
      }, 7000);
    }
	if(role === "Bank") {
		 // Below get requedst returns the details of the tables entries
    // Change the below URL to realtime one
    axios
      .get(`http://localhost:8080/bidding/allocated`)
      .then(res => {
        const persons = res.data;
        this.setState({ persons });
      });
	}
  }
  componentDidMount() {
    //Plays the video of natwest 6 secs once
    setInterval(function() {
      document.getElementById("vid").play();
    }, 6000);

    // Below get requedst returns the details of the tables entries
    // Change the below URL to realtime one
    axios
      .get(`http://localhost:8080/bidding/allocated`)
      .then(res => {
        const persons = res.data;
        this.setState({ persons });
      });

    // Below request is for the Bid from prepopulated values
    axios
      .get(`http://www.json-generator.com/api/json/get/ceEcoUzGxu?indent=2`)
      .then(res => {
        const bidding = res.data;
        this.setState({ bidding });
      });
  }

  render() {
    let items = [],
      data = [];
    this.state.persons.forEach(function(item) {
      items.push(item);
    });
    items.forEach(function(item) {
      data.push(item);
    });
    console.log(this.state);
    if(this.state.role === "home") {
		return (
		        <div>
		          <div className="list-view">
		           <input
				  		              type="button"
				  		              value="Home"
				  		              onClick={e => this.handleChangeView(e)}
		            />
		            <input
		              type="button"
		              value="Bid"
		              onClick={e => this.handleChangeView(e)}
		            />
		            <input
		              type="button"
		              value="Investor"
		              onClick={e => this.handleChangeView(e)}
		            />
		            <input
		              type="button"
		              value="Bank"
		              onClick={e => this.handleChangeView(e)}
		            />
          </div></div>);
	}
    if (this.state.role === "Bank") {
      return (
        <div>
          <div className="list-view">
            <input
		   				  		              type="button"
		   				  		              value="Home"
		   				  		              onClick={e => this.handleChangeView(e)}
		            />
            <input
              type="button"
              value="Bank"
              onClick={e => this.handleChangeView(e)}
            />
          </div>
          <MaterialTable
            columns={[
              {
                title: "Investor Name",
                field: "investorName",
                cellStyle: {
                  backgroundColor: "#039be5",
                  color: "#FFF"
                },
                headerStyle: {
                  backgroundColor: "#039be5"
                }
              },
              { title: "Bidded Coupon Rate", field: "biddedCouponRate" },
              { title: "Total Bidded Amount", field: "biddedAmount" },
              { title: "Cummulative Bid Amount", field: "cumulativeAmount" },
              { title: "No of Bonds Issued", field: "noOfBondsIssued" },
				  {title: "Bid Status", field:"bidStatus"}
            ]}
            data={items}
            title={this.state.role + " Dashboard"}
            options={{
              headerStyle: {
                backgroundColor: "#01579b",
                color: "#FFF"
              },
              filtering: true
            }}
          />
        </div>
      );
    } else if (this.state.role === "Bid") {
      return (
        <div>
          <div className="list-view">
           <input type="button" value="Home" onClick={e => this.handleChangeView(e)}/>
            <input
              type="button"
              value="Bid"
              onClick={e => this.handleChangeView(e)}
            />
            <input
              type="button"
              value="Investor"
              onClick={e => this.handleChangeView(e)}
            />
          </div>
          <form onSubmit={this.handleSubmit}>
            <label className="field">
              <span>Issuer Name</span>
              {console.log(this.state.binding)}
              <input
                type="text"
                value="Google"
                disabled
              />
            </label>
            <label className="field">
              <span>Bond Name</span>
              <input type="text" value="Bond-G" disabled />
            </label>
            <label className="field">
              <span>Actual Coupon Rate</span>
              <input
                type="text"
                value="9%"
                disabled
              />
            </label>
            <label className="field">
              <span>Investor Id</span>
              <input type="text" onChange={this.investorId} />
            </label>
            <label className="field">
              <span>Bidding Amount</span>
              <input type="text" onChange={this.biddingAmount} />
            </label>
            <label className="field">
              <span>Bidding Coupon Rate</span>
              <input type="text" onChange={this.couponRate} />
            </label>

            <input
              type="submit"
              value="Submit"
              id="submit "
              className="submit"
              disabled={this.state.disabled}
            />
          </form>
        </div>
      );
    } else if (this.state.role === "Investor") {return (
        <div>
          <div className="list-view">
           <input
		  				  		              type="button"
		  				  		              value="Home"
		  				  		              onClick={e => this.handleChangeView(e)}
		            />
            <input
              type="button"
              value="Bid"
              onClick={e => this.handleChangeView(e)}
            />
            <input
              type="button"
              value="Investor"
              onClick={e => this.handleChangeView(e)}
            />
          </div>
          <MaterialTable
            columns={[
              {
                title: "Bond Name",
                field: "bondName",
                cellStyle: {
                  backgroundColor: "#039be5",
                  color: "#FFF"
                },
                headerStyle: {
                  backgroundColor: "#039be5"
                }
              },
              { title: "Bidded Coupon Rate", field: "bidCouponRate" },
              { title: "No Of Bonds Issued", field: "bondsIssued" },
              { title: "Total Bidded Amount", field: "biddedAmount" },
              { title: "Balance Refund", field: "balanceRefund" },
              { title: "Maturity Date", field: "maturityDate" },
              { title: "Payment Frequency", field: "paymentFreq" },
              { title: "Bid Status", field: "bidStatus" }
            ]}
            data={items}
            title={this.state.role + " Dashboard"}
            options={{
              headerStyle: {
                backgroundColor: "#01579b",
                color: "#FFF"
              },
              filtering: true
            }}
          />
        </div>
      );}
    else {
      return (
        <div>
          <div className="list-view">
           <input
		  				  		              type="button"
		  				  		              value="Home"
		  				  		              onClick={e => this.handleChangeView(e)}
		            />
            <input
              type="button"
              value="Investor"
              onClick={e => this.handleChangeView(e)}
            />
            <input
              type="button"
              value="Bank"
              onClick={e => this.handleChangeView(e)}
            />
          </div>
        </div>
      );
    }
  }
}

export default App;

const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);
